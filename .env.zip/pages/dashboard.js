import DashboardSidebar from "../components/DashboardSidebar";
export default function Dashboard() { return <div><DashboardSidebar />Dashboard Content</div>; }