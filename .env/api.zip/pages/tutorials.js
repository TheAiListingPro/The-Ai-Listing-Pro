export default function Tutorials() {
  return (
    <div>
      <h1>Tutorials</h1>
      <ul>
        <li>How to generate an AI-powered listing</li>
        <li>How to connect your Stripe account</li>
        <li>How to automate approvals with Zapier</li>
      </ul>
    </div>
  );
}